<?php
// File: /nobatsabz/config.php
// (نسخه ۲.۲ با آدرس صفحه زمان‌بندی)

// --- نمایش خطا ---
// ini_set('display_errors', 1);
// error_reporting(E_ALL);

// --- منطقه زمانی ---
date_default_timezone_set('Asia/Tehran');

// --- تنظیمات ربات تلگرام ---
define('BOT_TOKEN', '8332279975:AAFtyAuvjC7Pii3SVvbs-vYz6YIcjRkUPXw');
define('BOT_USERNAME', 'sabztime_bot'); // نام کاربری ربات بدون @
define('BOT_API_URL', 'https://api.telegram.org/bot' . BOT_TOKEN . '/');

// --- تنظیمات وبهوک و وب-اپ ---
define('BASE_URL', 'https://webnovo.ir/project');

define('WEBAPP_URL', BASE_URL . '/webapp/index.html?v=1.0');
define('WEBAPP_URL_EDIT', BASE_URL . '/webapp/edit.html?v=1.1');

// *** NEW: آدرس صفحه مدیریت زمان‌بندی ***
define('WEBAPP_URL_SCHEDULE', BASE_URL . '/webapp/schedule.html?v=1.0');

// *** NEW: آدرس صفحه مدیریت خدمات ***
define('WEBAPP_URL_SERVICES', BASE_URL . '/webapp/services.html?v=1.0');

define('WEBHOOK_URL', BASE_URL . '/bot/webhook.php'); 

// --- تنظیمات پایگاه داده ---
define('DB_HOST', 'localhost');
define('DB_NAME', 'webnovoi_reza');
define('DB_USER', 'webnovoi_reza');
define('DB_PASS', 'jHLSa[-4]srP');
define('DB_CHARSET', 'utf8mb4');

// SQLite database path
define('DB_PATH', __DIR__ . '/database/booking_system.db');

// --- حالت توسعه ---
define('DEV_MODE', false);

// --- تنظیمات عضویت اجباری کانال ---
// شناسه عددی کانال (ترجیحی برای دقت)، در صورت خالی از USERNAME استفاده می‌شود
// مثال: 123456789 یا -1001234567890 برای سوپرگروه/کانال
define('REQUIRED_CHANNEL_ID', 0); // TODO: مقدار واقعی را جایگزین کنید
// نام کاربری کانال بدون @ برای لینک و جایگزین
define('REQUIRED_CHANNEL_USERNAME', 'sabztimebot'); // TODO: مقدار واقعی را جایگزین کنید

// --- تنظیمات مدیریت (ادمین داشبورد) ---
// برای امنیت، بهتر است این مقادیر را به‌صورت متغیر محیطی در سرور تنظیم کنید.
// در صورت عدم وجود متغیر محیطی، از مقادیر پیش‌فرض زیر استفاده می‌شود.
define('ADMIN_USERNAME', getenv('ADMIN_USERNAME') ?: 'rsabzi714');
define('ADMIN_PASSWORD', getenv('ADMIN_PASSWORD') ?: 'Rsabzi199622@');

// --- سکرت داخلی برای فراخوانی‌های سرور-به-سرور بین webhook.php و customer_credit_api.php ---
// این مقدار فقط باید بین این دو فایل مشترک باشد. هرگز در فرانت‌اند/وب‌اپ‌ها استفاده نشود.
define('INTERNAL_API_SECRET', getenv('INTERNAL_API_SECRET') ?: '02fc0cd30ab026c04c8271f57635837698602a92742c6666e73d3fe7441589df');

// --- اتصال به پایگاه داده (PDO) ---
$pdo = null;
try {
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    // Set charset explicitly for proper Persian character handling
    $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
    error_log("اتصال به پایگاه داده MySQL موفق");
} catch (PDOException $e) {
    error_log("اتصال به پایگاه داده MySQL ناموفق: " . $e->getMessage());
    $pdo = null;
    // در صورت عدم اتصال به MySQL، سیستم متوقف می‌شود
    throw new Exception("اتصال به پایگاه داده MySQL امکان‌پذیر نیست: " . $e->getMessage());
}
?>
