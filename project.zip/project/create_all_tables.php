<?php
// اسکریپت ایجاد تمام جداول در SQLite
require_once 'config.php';

try {
    // ایجاد جدول users
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            telegram_id INTEGER NOT NULL UNIQUE,
            first_name TEXT NOT NULL,
            last_name TEXT,
            username TEXT,
            phone TEXT,
            email TEXT,
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");
    echo "جدول users ایجاد شد.\n";

    // ایجاد جدول marketers
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS marketers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            marketer_code TEXT NOT NULL UNIQUE,
            total_businesses INTEGER DEFAULT 0,
            total_bookings INTEGER DEFAULT 0,
            commission_rate REAL DEFAULT 0.0,
            total_commission REAL DEFAULT 0.0,
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    ");
    echo "جدول marketers ایجاد شد.\n";

    // ایجاد جدول businesses
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS businesses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            province TEXT,
            city TEXT,
            address TEXT,
            phone TEXT,
            email TEXT,
            website TEXT,
            business_type TEXT,
            slot_duration_minutes INTEGER DEFAULT 30,
            advance_booking_days INTEGER DEFAULT 14,
            marketer_id INTEGER,
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (marketer_id) REFERENCES marketers(id) ON DELETE SET NULL
        )
    ");
    echo "جدول businesses ایجاد شد.\n";

    // ایجاد جدول services
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS services (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            business_id INTEGER NOT NULL,
            name TEXT NOT NULL,
            description TEXT,
            duration_minutes INTEGER NOT NULL,
            price REAL DEFAULT 0.0,
            is_active INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE
        )
    ");
    echo "جدول services ایجاد شد.\n";

    // ایجاد جدول bookings
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            business_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            service_id INTEGER,
            booking_date DATE NOT NULL,
            start_time TIME NOT NULL,
            end_time TIME NOT NULL,
            duration_minutes INTEGER NOT NULL,
            customer_name TEXT NOT NULL,
            customer_phone TEXT,
            customer_notes TEXT,
            status TEXT DEFAULT 'pending',
            confirmation_code TEXT,
            total_price REAL DEFAULT 0.0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (business_id) REFERENCES businesses(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (service_id) REFERENCES services(id) ON DELETE SET NULL
        )
    ");
    echo "جدول bookings ایجاد شد.\n";

    echo "تمام جداول با موفقیت ایجاد شدند!\n";

} catch (PDOException $e) {
    echo "خطا در ایجاد جداول: " . $e->getMessage() . "\n";
}
?>